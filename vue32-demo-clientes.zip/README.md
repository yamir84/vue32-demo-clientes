# VUE32 Admin Tool v2

## Comando de Instalación
* ESP32 de 4MB de memoria Flash
python esptool.py -b 921600 --port COM7 write_flash --flash_freq 80m 0x00010000 firmware.bin

## Acceder al curso en Udemy en este Link:
https://www.udemy.com/course/vue32-admin-tool-v2-servidor-web/?referralCode=FD94C260C13C00CA43D2

## Acceder al DEMO en este Link:
https://github.com/yamir84/vue32-demo-clientes

## Acceso a la RED AP
* SSID AP Ejemplo  : ESP328B1C72100C4D
* Password SSID AP : adminserver32

## Acceder a la WEB para configurar
* IP  : 192.168.4.1
* mDNS: (ver el video)

## Usuario y Contraseña WEB
* User:     admin
* Password: admin

## A disfrutar del ESP32 WebSettings

## Video en YouTube
https://youtu.be/5WETHuWSTtc